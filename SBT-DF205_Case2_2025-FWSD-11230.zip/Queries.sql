-- ============================================================
-- SBT-DF205 CASE 2 - iOS FORENSICS
-- SQL QUERIES USED DURING EXAMINATION
-- ============================================================


-- ------------------------------------------------------------
-- TASK 2 - ACCOUNTS3.SQLITE
-- Purpose: Inspect account tables and identify account records.
-- ------------------------------------------------------------

SELECT name
FROM sqlite_master
WHERE type='table'
ORDER BY name;

PRAGMA table_info(ZACCOUNT);

SELECT *
FROM ZACCOUNT;

SELECT
    a.Z_PK AS Account_ID,
    a.ZUSERNAME AS Username,
    a.ZACCOUNTDESCRIPTION AS Description,
    a.ZACCOUNTTYPE AS Type_ID,
    t.ZACCOUNTTYPEDESCRIPTION AS Account_Type,
    t.ZIDENTIFIER AS Type_Identifier
FROM ZACCOUNT a
LEFT JOIN ZACCOUNTTYPE t
ON a.ZACCOUNTTYPE = t.Z_PK
WHERE a.ZUSERNAME IS NOT NULL
ORDER BY a.Z_PK;


-- ------------------------------------------------------------
-- TASK 3 - SMS.DB
-- Purpose: Examine SMS/iMessage records.
-- ------------------------------------------------------------

SELECT name
FROM sqlite_master
WHERE type='table'
ORDER BY name;

PRAGMA table_info(message);

SELECT COUNT(*) AS Total_Messages
FROM message;

SELECT
    CASE
        WHEN is_from_me=1 THEN 'Sent'
        WHEN is_from_me=0 THEN 'Received'
        ELSE 'Unknown'
    END AS Direction,
    COUNT(*) AS Count
FROM message
GROUP BY is_from_me;

SELECT
    m.ROWID AS Message_ID,
    h.id AS Participant,
    m.text AS Message_Text,
    m.service AS Service,
    m.is_from_me AS Is_From_Me,
    m.date AS Raw_Date
FROM message m
LEFT JOIN handle h
ON m.handle_id=h.ROWID
ORDER BY m.date
LIMIT 20;

SELECT
    m.ROWID AS Message_ID,
    h.id AS Participant,
    m.text AS Message_Text,
    CASE
        WHEN m.is_from_me=1 THEN 'Sent'
        WHEN m.is_from_me=0 THEN 'Received'
        ELSE 'Unknown'
    END AS Direction,
    m.service AS Service,
    m.date AS Raw_Date,
    datetime((m.date/1000000000.0)+978307200,'unixepoch') AS UTC_Time
FROM message m
LEFT JOIN handle h
ON m.handle_id=h.ROWID
ORDER BY m.date;


-- ------------------------------------------------------------
-- MESSAGE ATTACHMENTS
-- ------------------------------------------------------------

SELECT COUNT(*) AS Attachment_Count
FROM attachment;

SELECT
    ROWID AS Attachment_ID,
    filename,
    mime_type,
    transfer_name,
    total_bytes,
    created_date
FROM attachment
ORDER BY ROWID;

SELECT
    maj.message_id AS Message_ID,
    maj.attachment_id AS Attachment_ID,
    m.text AS Message_Text,
    a.filename AS Attachment_Path
FROM message_attachment_join maj
JOIN message m
ON maj.message_id=m.ROWID
JOIN attachment a
ON maj.attachment_id=a.ROWID
ORDER BY maj.message_id;


-- ------------------------------------------------------------
-- ADDRESSBOOK.SQLITEDB
-- Purpose: Associate communication identifiers with contacts.
-- ------------------------------------------------------------

SELECT
    p.ROWID AS Contact_ID,
    p.First,
    p.Last,
    mv.value AS Identifier
FROM ABPerson p
JOIN ABMultiValue mv
ON mv.record_id=p.ROWID
WHERE mv.value IS NOT NULL
ORDER BY p.ROWID;


-- ------------------------------------------------------------
-- CALLHISTORY.STOREDATA
-- Purpose: Examine call records with UTC conversion.
-- ------------------------------------------------------------

PRAGMA table_info(ZCALLRECORD);

SELECT
    Z_PK AS Call_ID,
    CASE
        WHEN ZORIGINATED=1 THEN 'Outgoing'
        WHEN ZORIGINATED=0 THEN 'Incoming'
        ELSE 'Unknown'
    END AS Direction,
    ZDATE AS Raw_Date,
    datetime(ZDATE+978307200,'unixepoch') AS UTC_Time,
    ZDURATION AS Duration_Seconds,
    ZLOCATION AS Location,
    ZSERVICE_PROVIDER AS Service
FROM ZCALLRECORD
ORDER BY ZDATE
LIMIT 5;


-- ------------------------------------------------------------
-- TASK 4 - SAFARI HISTORY.DB
-- ------------------------------------------------------------

PRAGMA table_info(history_items);

SELECT
    hv.id AS Visit_ID,
    hi.url AS URL,
    hv.visit_time AS Raw_Time,
    datetime(hv.visit_time+978307200,'unixepoch') AS UTC_Time
FROM history_visits hv
JOIN history_items hi
ON hv.history_item=hi.id
ORDER BY hv.visit_time
LIMIT 10;


-- ------------------------------------------------------------
-- CALENDAR.SQLITEDB
-- ------------------------------------------------------------

SELECT
    'Calendar' AS Table_Name,
    COUNT(*) AS Rows
FROM Calendar
UNION ALL
SELECT 'CalendarItem', COUNT(*) FROM CalendarItem
UNION ALL
SELECT 'Location', COUNT(*) FROM Location
UNION ALL
SELECT 'Participant', COUNT(*) FROM Participant
UNION ALL
SELECT 'Recurrence', COUNT(*) FROM Recurrence
UNION ALL
SELECT 'OccurrenceCache', COUNT(*) FROM OccurrenceCache;

SELECT
    ROWID AS Event_ID,
    summary AS Summary,
    start_date AS Raw_Start,
    datetime(start_date+978307200,'unixepoch') AS Start_UTC,
    end_date AS Raw_End,
    datetime(end_date+978307200,'unixepoch') AS End_UTC,
    start_tz AS Start_TZ
FROM CalendarItem
WHERE summary IS NOT NULL
ORDER BY start_date
LIMIT 10;


-- ------------------------------------------------------------
-- TASK 5 - PHOTOS.SQLITE
-- ------------------------------------------------------------

PRAGMA table_info(ZGENERICASSET);

SELECT
    Z_PK,
    ZFILENAME,
    ZDATECREATED,
    ZADDEDDATE,
    ZLATITUDE,
    ZLONGITUDE
FROM ZGENERICASSET
WHERE ZFILENAME IS NOT NULL
LIMIT 10;


-- ------------------------------------------------------------
-- TASK 6 - KNOWLEDGEC.DB
-- ------------------------------------------------------------

PRAGMA table_info(ZOBJECT);

SELECT
    Z_PK AS Record_ID,
    ZSTREAMNAME AS Stream,
    ZVALUESTRING AS Text_Value,
    ZVALUEINTEGER AS Integer_Value,
    ZVALUEDOUBLE AS Double_Value,
    ZSTARTDATE AS Raw_Start,
    datetime(ZSTARTDATE+978307200,'unixepoch') AS Start_UTC,
    ZENDDATE AS Raw_End,
    datetime(ZENDDATE+978307200,'unixepoch') AS End_UTC,
    ROUND(ZENDDATE-ZSTARTDATE,3) AS Duration_Seconds
FROM ZOBJECT
WHERE ZSTREAMNAME IS NOT NULL
ORDER BY ZSTARTDATE
LIMIT 10;

-- Safari / KnowledgeC correlation window
SELECT
    Z_PK AS Record_ID,
    ZSTREAMNAME AS Stream,
    ZVALUESTRING AS Text_Value,
    ZVALUEINTEGER AS Integer_Value,
    ZVALUEDOUBLE AS Double_Value,
    ZSTARTDATE AS Raw_Start,
    datetime(ZSTARTDATE+978307200,'unixepoch') AS Start_UTC,
    ZENDDATE AS Raw_End,
    datetime(ZENDDATE+978307200,'unixepoch') AS End_UTC,
    ROUND(ZENDDATE-ZSTARTDATE,3) AS Duration_Seconds
FROM ZOBJECT
WHERE ZSTARTDATE BETWEEN 607049800 AND 607050300
ORDER BY ZSTARTDATE;


-- ------------------------------------------------------------
-- TASK 7 - HEALTHDB_SECURE.SQLITE
-- ------------------------------------------------------------

PRAGMA table_info(quantity_samples);

PRAGMA table_info(samples);

SELECT
    s.data_id AS Sample_ID,
    s.data_type AS Data_Type,
    q.quantity AS Value,
    q.original_quantity AS Original_Value,
    q.original_unit AS Original_Unit,
    s.start_date AS Raw_Start,
    datetime(s.start_date+978307200,'unixepoch') AS Start_UTC,
    s.end_date AS Raw_End,
    datetime(s.end_date+978307200,'unixepoch') AS End_UTC
FROM samples s
JOIN quantity_samples q
ON s.data_id=q.data_id
ORDER BY s.start_date
LIMIT 10;


-- ------------------------------------------------------------
-- HEALTHDB.SQLITE - SOURCES AND DEVICES
-- ------------------------------------------------------------

SELECT *
FROM sources
LIMIT 5;

SELECT *
FROM source_devices
LIMIT 5;


-- ------------------------------------------------------------
-- LOCATIOND CACHE_ENCRYPTEDB.DB
-- ------------------------------------------------------------

PRAGMA table_info(CellLocation);

SELECT *
FROM CellLocation
LIMIT 3;

SELECT *
FROM WifiLocation
LIMIT 3;


-- ------------------------------------------------------------
-- ROUTINED LOCAL.SQLITE
-- ------------------------------------------------------------

PRAGMA table_info(ZRTLEARNEDVISITMO);

PRAGMA table_info(ZRTLEARNEDLOCATIONOFINTERESTMO);

SELECT *
FROM ZRTLEARNEDVISITMO
LIMIT 5;

SELECT
    Z_PK AS Record_ID,
    ZLOCATIONLATITUDE AS Latitude,
    ZLOCATIONLONGITUDE AS Longitude,
    ZLOCATIONUNCERTAINTY AS Uncertainty,
    ZCONFIDENCE AS Confidence,
    ZPLACECREATIONDATE AS Raw_Creation,
    datetime(ZPLACECREATIONDATE+978307200,'unixepoch') AS Creation_UTC
FROM ZRTLEARNEDLOCATIONOFINTERESTMO
WHERE ZLOCATIONLATITUDE IS NOT NULL
AND ZLOCATIONLONGITUDE IS NOT NULL
LIMIT 3;
